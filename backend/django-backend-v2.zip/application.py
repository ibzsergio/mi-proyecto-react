#!/usr/bin/env python3
import os
import sys

# Agregar el directorio actual al Python path
path = os.path.dirname(os.path.abspath(__file__))
if path not in sys.path:
    sys.path.insert(0, path)

# Configurar Django settings
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'backend.settings')

# Importar y configurar Django
import django
from django.conf import settings
from django.core.wsgi import get_wsgi_application

# Configurar Django
django.setup()

# Crear la aplicación WSGI
application = get_wsgi_application()